"""
Flight Dashboard Web Application
Main Flask application entry point
"""
from flask import Flask, render_template, session, jsonify, redirect, url_for
from config import Config
from routes.api import api_bp, set_data_processor, get_data_processor
from routes.upload import upload_bp
from routes.manifesto import manifesto_bp
from routes.salesforce import salesforce_bp
from routes.tracker import tracker_bp
import os

# Ensure templates/static paths work when running from trackerrevo folder
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
app = Flask(__name__,
    template_folder=os.path.join(BASE_DIR, 'templates'),
    static_folder=os.path.join(BASE_DIR, 'static'))
app.config.from_object(Config)
Config.init_app(app)
app.secret_key = Config.SECRET_KEY

@app.context_processor
def inject_now():
    from datetime import datetime
    return {'now': datetime.now}

# Register blueprints
app.register_blueprint(api_bp, url_prefix='/api')
app.register_blueprint(upload_bp, url_prefix='/api')
app.register_blueprint(manifesto_bp, url_prefix='/api/manifesto')
app.register_blueprint(salesforce_bp, url_prefix='/api/salesforce')
app.register_blueprint(tracker_bp)

# Load cache automatically on first request
@app.before_request
def load_cache_if_needed():
    """Load cached data automatically if not already loaded"""
    processor = get_data_processor()
    if processor is None:
        try:
            from services.cache_service import get_cache_service
            cache = get_cache_service()
            
            if cache.cache_exists():
                processor = cache.load_processor_state()
                if processor is not None:
                    set_data_processor(processor)
        except Exception as e:
            pass  # Silently fail, will try again on next request


@app.route('/health')
def health():
    """Health check para Cloud Run"""
    return jsonify({'status': 'ok', 'service': 'trackerrevo'}), 200


@app.route('/')
def index():
    """Redireciona para o radar (única página do serviço)"""
    return redirect(url_for('tracker.tracker_page'))


if __name__ == '__main__':
    print("="*60)
    print("Flight Dashboard Web Application")
    print("="*60)
    
    # Get port from environment (for production) or use 5050 (macOS AirPlay often uses 5000)
    port = int(os.environ.get('PORT', 5050))
    debug_mode = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    # Get local IP for network access
    import socket
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        local_ip = s.getsockname()[0]
        s.close()
    except:
        local_ip = "localhost"
    
    print(f"Running on http://0.0.0.0:{port}")
    print(f"Local access: http://localhost:{port}")
    print(f"Network access: http://{local_ip}:{port}")
    print(f"Upload folder: {Config.UPLOAD_FOLDER}")
    print(f"Cache folder: {Config.CACHE_FOLDER}")
    print(f"Debug mode: {debug_mode}")
    print("="*60)
    
    # Load cache before starting server
    try:
        from services.cache_service import get_cache_service
        cache = get_cache_service()
        
        if cache.cache_exists():
            from routes.api import set_data_processor
            processor = cache.load_processor_state()
            if processor is not None:
                set_data_processor(processor)
                cache_info = cache.get_cache_info()
                if cache_info:
                    print(f"✓ Cache carregado: {cache_info.get('total_records', 0):,} registros")
                    print(f"  Salvo em: {cache_info.get('saved_at', 'N/A')}")
        else:
            print("⚠️  Cache não encontrado. Faça upload de dados para gerar cache.")
    except Exception as e:
        print(f"⚠️  Erro ao carregar cache: {e}")
    
    print("="*60)
    
    app.run(debug=debug_mode, host='0.0.0.0', port=port)

